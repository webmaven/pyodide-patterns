def format_greeting(name):
    """Formats a greeting string."""
    return f"Hello, {name}!"
